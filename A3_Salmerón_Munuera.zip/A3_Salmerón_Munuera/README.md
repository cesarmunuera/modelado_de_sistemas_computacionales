# modelado_de_sistemas_computacionales
Modelado de Sistemas Computacionales -- 3º GIC

César Munuera Pérez y Sergio Salmerón González


En la carpeta SOURCES, se encuentran spi_controller.vhd, y los archivos de 
configuración de las ventanas de formas de onda.
El archivo .bit es el test_oled.bit .




